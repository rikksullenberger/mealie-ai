

![Recipe Image](../images/huevos-rancheros-con-rajas-y-champinones.jpg)

# Huevos Rancheros con Rajas y Champiñones
For his take on this classic Mexican dish, which originated as a simple but hearty ranchers' breakfast, Rick Martinez adds a layer of cheesy sautéed poblanos and mushrooms to the tostada-egg-salsa trio.

## Ingredients

- [ ] 1 serrano chile

- [ ] 16 oz. cherry tomatoes (about 3 cups)

- [ ] ¼ onion

- [ ] ¼ cup cilantro leaves with tender stems, plus more for serving

- [ ] 3 tsp. Diamond Crystal or 1½ tsp. Morton kosher salt, divided, plus more

- [ ] 1½ tsp. (or more) fresh lime juice

- [ ] 8 oz. button mushrooms

- [ ] 2 medium poblano chiles or any color bell peppers

- [ ] 2 garlic cloves

- [ ] 6 oz. white cheddar

- [ ] 5 Tbsp. extra-virgin olive oil, divided

- [ ] 4 large eggs

- [ ] 4 tostadas


## Instructions

- [ ] Make the salsa ranchera: Remove stem from 1 serrano chile (only use ½ if you don’t want your salsa spicy) and halve lengthwise. Heat a medium skillet, preferably cast iron, over high until you see wisps of smoke, about 2 minutes. Arrange serrano chile, skin side down, on one side of pan and add 16 oz. cherry tomatoes. Cook, leaving chile undisturbed and occasionally tossing tomatoes, until charred, 6–8 minutes. It is going to get a little smoky so turn on the vent and open a window. Transfer serrano chile and tomatoes to a blender or food processor. Reserve skillet.

- [ ] Add ¼ onion, ¼ cup cilantro leaves with tender stems, and 1 tsp. Diamond Crystal or ½ tsp. Morton kosher salt to blender and blend on low speed (or pulse if using a food processor) until vegetables are broken up, about 30 seconds. Increase speed to medium-low and purée until salsa is almost smooth but some chunks remain. Don’t be tempted to blend on high or you will incorporate air into the salsa and it will look and taste more like a smoothie than a salsa. Transfer to a medium bowl and stir in 1½ tsp. fresh lime juice. Taste and season with more salt and add more lime juice if needed. Set aside until ready to serve.

- [ ] Using a paper towel, brush off dirt from 8 oz. button mushrooms. Trim woody stems and discard. Cut mushrooms into quarters. Cut 2 medium poblano chiles or any color bell peppers in half lengthwise and remove stems, seeds, and ribs. Cut chiles into long thin strips about ¼" thick. Use the side of a chef’s knife to lightly smash 2 garlic cloves, then peel and thinly slice. Grate 6 oz. white cheddar on the large holes of a box grater.

- [ ] Head over to the stove with all of your prep work (gathering it on a rimmed baking sheet will make this easy!). Now, you’re ready to make the mushroom topping. Wipe out reserved skillet with a paper towel and heat 3 Tbsp. extra-virgin olive oil over medium-high. Arrange mushrooms in a single layer in skillet and cook, undisturbed, until brown underneath, about 3 minutes. Give mushrooms a toss and season with 1 tsp. Diamond Crystal or ½ tsp. Morton kosher salt. Continue to cook, tossing occasionally, until deep golden brown all over, 5–7 minutes longer. Using a slotted spoon, transfer to a small bowl, leaving oil behind.

- [ ] Arrange poblano chiles in an even layer in same skillet and cook, undisturbed, until browned underneath, about 2 minutes. Add garlic and season with 1 tsp. Diamond Crystal or ½ tsp. Morton kosher salt. Cook, tossing occasionally, until lightly browned all over, 5–7 minutes longer. Add 3 Tbsp. water and cook, stirring occasionally, until water has evaporated, about 2 minutes. The water will soften the chiles and pull up all those tasty brown bits from the bottom of the pan.

- [ ] Add mushrooms with any accumulated juices back to pan and toss until evenly distributed. Sprinkle cheese over in an even layer and remove skillet from heat. Cover (a baking sheet works great if you don’t have a lid that will work) and let sit 5 minutes for cheese to melt.

- [ ] You are almost there; you just need to cook the eggs. Heat remaining 2 Tbsp. extra-virgin olive oil in a large nonstick skillet over medium-high. Crack 4 large eggs into skillet, leaving space around each one, and cook until whites are set and edges are crisp, about 4 minutes. Season with salt.

- [ ] To serve, spoon cheesy mushroom mixture onto 4 tostadas, dividing evenly, and top each with an egg, then reserved salsa and some cilantro.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/huevos-rancheros-con-rajas-y-champinones