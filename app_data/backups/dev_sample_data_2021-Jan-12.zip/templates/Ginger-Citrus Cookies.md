

![Recipe Image](../images/ginger-citrus-cookies.jpg)

# Ginger-Citrus Cookies
Blanching the citrus peel in several changes of boiling water removes bitterness while still leaving plenty of bright flavor behind.

## Ingredients

- [ ] 2 cups 1"–2"-wide strips lemon, lime, orange, or grapefruit zest (pith removed)

- [ ] 2 cups granulated sugar

- [ ] 1 tsp. ground ginger

- [ ] ½ tsp. ground cardamom

- [ ] ½ tsp. ground cinnamon

- [ ] ¼ tsp. ground cloves

- [ ] 3½ cups all-purpose flour

- [ ] 1 Tbsp. baking soda

- [ ] 1 tsp. Diamond Crystal or ½ tsp. Morton kosher salt

- [ ] ½ tsp. freshly ground white pepper

- [ ] 10 Tbsp. unsalted butter, room temperature

- [ ] 1 cup granulated sugar

- [ ] ½ cup (packed) light brown sugar

- [ ] 2 large eggs

- [ ] ¾ cup mild-flavored (light) molasses


## Instructions

- [ ] Place citrus zest in a medium saucepan and pour in cold water to cover. Bring to a boil; drain. Repeat process 2 more times.

- [ ] Combine sugar and 2 cups water in same saucepan; bring to a boil, stirring to dissolve sugar. Add citrus zest and bring just to a simmer. Reduce heat to low and simmer very gently until peels are translucent, 30–45 minutes. Remove from heat and let citrus zest cool in syrup.

- [ ] Drain citrus zest and finely chop. Spread out on a rimmed baking sheet; let sit until dry.

- [ ] Preheat oven to 350°. Toast ginger, cardamom, cinnamon, and cloves in a small skillet over medium heat, stirring with a wooden spoon, until fragrant, about 2 minutes. Remove from heat.

- [ ] Sift toasted spices, flour, baking soda, salt, and white pepper into a medium bowl or onto a sheet of wax paper.

- [ ] Using an electric mixer on medium-high speed, beat butter and both sugars in a large bowl until light and fluffy, about 4 minutes. Add eggs one at a time, beating well after each addition and scraping down sides of bowl as needed. Beat in molasses. Gradually add dry ingredient in 2 batches, beating on low speed to incorporate after each addition. Stir in 1 cup candied citrus peel.

- [ ] Drop dough by rounded tablespoons between 2 parchment-lined baking sheets, spacing 2" apart. Bake cookies until tops feel firm when lightly touched, 10–12 minutes. Let cool on baking sheets about 2 minutes, then transfer to a wire rack and let cool completely.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/ginger-citrus-cookies