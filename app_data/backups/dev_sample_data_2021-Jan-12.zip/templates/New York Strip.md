

![Recipe Image](../images/new-york-strip.jpg)

# New York Strip
Cooking a steak in a water bath is the ultimate, both in terms of flavor and laziness. Dial in a precise temperature, then go take a nap.

## Ingredients

- [ ] NY Strip Steak(s)

- [ ] salt to taste


## Instructions

- [ ] Bag the steak(s) and drop into 140° sous vide bath for 2 hours (or consult this handy [ChefSteps chart](https://s3.amazonaws.com/chefsteps/static/ChefSteps-SousVideReference.pdf))

- [ ] Pull from the bag, pat dry

- [ ] Sear in a scorching hot pan (butter + herb optional)

- [ ] Slice on a bias and sprinkle with sea salt




---

Tags: ['mains', ' meat']
Categories: []
Original URL: 