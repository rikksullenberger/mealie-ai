

![Recipe Image](../images/one-minute-muffin.jpg)

# One Minute Muffin
This flax muffin is quick, vertsatile (just mix in other goodies), and only makes one at a time, so you've got no huge tray to tempt you. Custom muffins every morning!

## Ingredients

- [ ] 1⁄4 cup flax seed meal

- [ ] 1⁄2 teaspoon baking powder

- [ ] 1 teaspoon cinnamon

- [ ] 1 egg

- [ ] 1 teaspoon oil

- [ ] sugar to taste (or honey, stevia)


## Instructions

- [ ] Mix all ingredients in a coffee mug.

- [ ] Micorowave for one minute on high.




---

Tags: ['breakfast']
Categories: []
Original URL: 