

![Recipe Image](../images/tamarind-chicken-thighs-with-collard-greens-salad.jpg)

# Tamarind Chicken Thighs With Collard Greens Salad
Tamarind concentrate gives this chicken its sticky, glossy quality, not to mention its sweet-and-sour flavor.

## Ingredients

- [ ] 8 skin-on, bone-in chicken thighs  (about 2½ lb.), patted dry

- [ ] Kosher salt

- [ ] 2 serrano chiles, coarsely chopped

- [ ] 1 2" piece ginger, peeled,  chopped

- [ ] 3 garlic cloves

- [ ] ⅓ cup tamarind concentrate

- [ ] 3 Tbsp. coconut aminos

- [ ] 2 Tbsp. agave nectar

- [ ] 2 tsp. ground cinnamon

- [ ] 1 tsp. ground nutmeg

- [ ] ½ cup plus 3 Tbsp. fresh orange juice (from about 2 oranges)

- [ ] 3 Tbsp. extra-virgin olive oil, divided

- [ ] 2 medium Japanese sweet potatoes or other sweet potatoes (about  1 lb.), scrubbed, sliced into 1/8"–1/4"-thick rounds

- [ ] Half a bunch collard greens (about 6 oz.), stems removed, leaves cut or torn into bite-size pieces

- [ ] Freshly ground black pepper


## Instructions

- [ ] Preheat oven to 375°. Place chicken in a large bowl and season all over with salt; set aside.

- [ ] Blend chiles, ginger, garlic, tamarind concentrate, coconut aminos, agave, cinnamon, nutmeg, and ½ cup orange juice in a blender until smooth. Transfer to a small saucepan and place over medium heat. Cook, stirring often, until glaze is sticky and easily coats a spoon, 6–8 minutes. Let cool. Pour glaze over chicken and toss to coat.

- [ ] Pour 2 Tbsp. oil into a large skillet and, using tongs, arrange chicken, skin side down, in pan, leaving excess glaze behind in bowl. Cook, undisturbed, over medium heat, until skin is browned and crisp, 10–12 minutes. Transfer chicken to a plate.

- [ ] Let skillet cool 5 minutes, then arrange sweet potatoes in an even, slightly overlapping layer in pan. Season with salt and add 2 Tbsp water. Place chicken, skin side up, on top. Transfer pan to oven and roast until chicken is cooked through and juices run clear when flesh is pierced with the tip of a small knife, 10–12 minutes. Let rest in pan 10 minutes.

- [ ] While the chicken is resting, toss collard greens, remaining 3 Tbsp. orange juice, and remaining 1 Tbsp. oil in a large bowl to combine; season with a pinch of salt and a few grinds of pepper. Lightly massage greens with your hands to soften slightly.

- [ ] Serve chicken and sweet potatoes with collard greens salad alongside.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/tamarind-chicken-thighs-with-collard-greens-salad