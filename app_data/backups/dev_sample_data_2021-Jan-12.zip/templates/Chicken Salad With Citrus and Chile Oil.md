

![Recipe Image](../images/chicken-salad-with-citrus-and-chile-oil.jpg)

# Chicken Salad With Citrus and Chile Oil
With plenty of protein, a double punch of acid from citrus and vinegar, and a garlicky chili oil, this salad is made for dinner.

## Ingredients

- [ ] 3 skin-on, bone-in chicken breasts  (about 1½ lb. total)

- [ ] Kosher salt, freshly ground pepper

- [ ] 2 Tbsp. plus ⅓ cup extra-virgin olive oil

- [ ] 3 garlic cloves, thinly sliced

- [ ] 2 tsp. paprika

- [ ] 1 tsp. coriander seeds, coarsely crushed

- [ ] ½ tsp. crushed red pepper flakes

- [ ] 2 medium endive, leaves separated

- [ ] 1 large head of radicchio, leaves  separated, torn if large

- [ ] 4 satsumas or blood oranges or 3 medium oranges, peeled, sliced into rounds, seeds removed

- [ ] 2 Tbsp. white wine vinegar or red wine vinegar

- [ ] 2 tsp. toasted sesame seeds, lightly crushed


## Instructions

- [ ] Preheat oven to 450°. Pat chicken breasts dry with paper towels; season on all sides with salt and pepper, then rub with 2 Tbsp. oil.

- [ ] Heat a large ovenproof skillet over medium-high. Arrange chicken, skin side down, in pan and cook, undisturbed, until skin is deep golden brown, about 3 minutes. Turn chicken over with tongs and transfer skillet to oven. Roast chicken until cooked all the way through, 15–17 minutes. Transfer to a cutting board and let cool 10 minutes.

- [ ] Meanwhile, cook garlic and remaining ⅓ cup oil in a small skillet over medium heat, stirring occasionally, until garlic is fragrant and pale golden, about 4 minutes. Immediately pour garlic oil into a small bowl and stir in paprika, coriander seeds, and red pepper flakes; season with salt.

- [ ] Cut chicken off the bone, then slice  ½" thick; discard bones.

- [ ] Toss endive, radicchio, and satsumas with vinegar and half of spiced garlic oil in a large bowl to combine; season salad with salt and pepper.

- [ ] Divide salad among plates or shallow bowls; top with chicken and drizzle with more spiced garlic oil. Sprinkle sesame seeds over.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/chicken-salad-with-citrus-and-chile-oil