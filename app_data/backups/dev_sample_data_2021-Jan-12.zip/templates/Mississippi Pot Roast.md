

![Recipe Image](../images/mississippi-pot-roast.jpg)

# Mississippi Pot Roast
This is the recipe that rocked reddit, coming our way via [Today](https://www.today.com/today/amp/tdna199419) (believe it or not). It takes just minutes with almost no prep (use a slow cooker liner for no cleanup), and the leftovers can be used for sandwiches or nachos or eggs. If you like a thicker gravy, combine the dripping with flour/starch, or just enjoy the thinner jus.

## Ingredients

- [ ] 3-4 lbs chuck roast

- [ ] 1 packet ranch mix

- [ ] 1 packet au jus gravy mix

- [ ] 1 stick butter

- [ ] 1 jar pepperoncinis


## Instructions

- [ ] In your slow cooker, add the roast and top with both packet mixes, a stick of butter (sliced into a few chunks), and a jar of pepperoncini peppers (the more the better, drained)

- [ ] Cook for 8 hours on low

- [ ] Serve with salt & vinegar potatoes




---

Tags: ['mains', ' crock pot']
Categories: []
Original URL: 