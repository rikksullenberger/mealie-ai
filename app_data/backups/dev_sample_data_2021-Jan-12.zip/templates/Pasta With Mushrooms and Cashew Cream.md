

![Recipe Image](../images/pasta-with-mushrooms-and-cashew-cream.jpg)

# Pasta With Mushrooms and Cashew Cream
Might you mistake this vegan cream for actual alfredo sauce? Maybe. Maybe not. It’s delicious either way.

## Ingredients

- [ ] 1 cup cashews

- [ ] 4 Tbsp. (or  more) extra-virgin olive oil, divided

- [ ] 6 oz. maitake mushrooms, torn into  bite-size pieces

- [ ] 6 oz. shiitake mushrooms, stems removed, torn into bite-size pieces

- [ ] Kosher salt

- [ ] 1 medium leek, white and pale green parts only, halved lengthwise, thinly sliced crosswise

- [ ] 2 medium shallots, finely chopped

- [ ] 2 garlic cloves, thinly sliced

- [ ] 12 oz. spaghetti or other long pasta

- [ ] 2 Tbsp. nutritional yeast

- [ ] 2 Tbsp. finely chopped parsley

- [ ] ½ lemon

- [ ] Freshly ground black pepper


## Instructions

- [ ] Preheat oven to 350°. Toast cashews on a rimmed baking sheet, tossing halfway through, until golden brown, 7–9 minutes. Let cool.

- [ ] Heat 2 Tbsp. oil in a large Dutch oven or other heavy pot over medium-high. Arrange half of mushrooms in a single layer in pot and cook, undisturbed, until edges are brown and starting to crisp, about 3 minutes. Give mushrooms a good toss, then continue to cook, tossing occasionally, until all sides are brown and crisp, about 5 minutes more. Using a slotted spoon, transfer mushrooms to a plate; season with salt. Repeat with remaining 2 Tbsp. oil, remaining mushrooms, and more salt.

- [ ] Reduce heat to medium-low and return all of the mushrooms to same pot. Add leeks, shallots, and garlic and cook, stirring often and adding another 1 Tbsp. oil if pan looks dry, until leeks and shallots are translucent and softened, about 4 minutes. Remove from heat.

- [ ] Meanwhile, cook pasta in a large pot of boiling salted water, stirring occasionally, until very al dente, about  2 minutes less than package directions (the pasta will finish cooking in the pan). Drain pasta, reserving ¾ cup pasta cooking liquid.

- [ ] Blend cashews, nutritional yeast, and pasta cooking liquid in a blender until very creamy. Set cashew cream aside.

- [ ] Return drained pasta to pot with mushroom mixture and add reserved cashew cream. Place over medium heat and cook, stirring well to coat, until pasta is al dente, about 3 minutes. Remove from heat. Add parsley and squeeze in juice from lemon half. Toss well to incorporate.

- [ ] Divide pasta evenly among shallow bowls or plates and top with several grinds of pepper.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/pasta-with-mushrooms-and-cashew-cream