

![Recipe Image](../images/corn-and-crab-beignets-with-yaji-aioli.jpg)

# Corn and Crab Beignets With Yaji Aioli
This ode to chef BJ Dennis and Gullah Geechee cuisine marries crabmeat with corn kernels for a crispy party starter. 

## Ingredients

- [ ] ½ cup unsalted dry-roasted peanuts

- [ ] 2 Tbsp. ground ginger

- [ ] 1 tsp. cayenne pepper

- [ ] 1 tsp. Diamond Crystal or ½ tsp. Morton kosher salt

- [ ] 1 tsp. garlic powder

- [ ] 1 tsp. onion powder

- [ ] 1 tsp. paprika

- [ ] 2 large egg yolks*

- [ ] 1 Tbsp. fresh lemon juice

- [ ] ¾ cup peanut oil

- [ ] 1 small shallot, finely chopped

- [ ] 1 garlic clove, finely grated

- [ ] 2 Tbsp. thinly sliced chives

- [ ] Kosher salt

- [ ] 4 Tbsp. unsalted butter

- [ ] 10 oz. frozen corn (about 2 cups)

- [ ] 2 Tbsp. thinly sliced chives

- [ ] 1½ cups all-purpose flour

- [ ] ½ cup cornmeal

- [ ] 2 tsp. baking powder

- [ ] 1½ tsp. Diamond Crystal or ¾ tsp. Morton kosher salt

- [ ] ½ tsp. cayenne pepper

- [ ] 1 large egg, beaten to blend

- [ ] 1 cup buttermilk

- [ ] 8 oz. lump crabmeat, picked over

- [ ] Vegetable oil (for frying; about 6 cups)

- [ ] * Raw egg is not recommended for the elderly, pregnant women, people with weakened immune systems…or people who don’t like raw egg.

- [ ] A deep-fry thermometer


## Instructions

- [ ] Pulse peanuts in a food processor until very finely chopped (be careful not to go too far; if you overprocess, the peanuts will turn into butter). Add ginger, cayenne, salt, garlic powder, onion powder, and paprika and pulse until powderlike.
Do ahead: Yaji can be made 3 months ahead. Transfer to an airtight container; cover and chill or freeze.

- [ ] Whisk egg yolks and lemon juice in a medium bowl to combine. Whisking constantly, add oil, starting with just a few drops at a time and gradually increasing to a fine steady stream. Whisk until all of the oil is incorporated and mixture is emulsified, about 4 minutes. Whisk in shallot, garlic, chives, and 1 Tbsp. yaji spice blend. Taste and season with salt.
Do ahead: Aioli can be made 3 days ahead. Cover and chill.

- [ ] Melt butter in a medium high-sided skillet over medium heat. Add corn and cook, stirring occasionally, until softened slightly and bright yellow, about 5 minutes. Transfer to a large bowl and stir in chives; let cool.

- [ ] Meanwhile, whisk flour, cornmeal, baking powder, salt, and cayenne in a medium bowl.

- [ ] Add egg and buttermilk to corn mixture and stir to combine. Add dry ingredients and stir again just to incorporate, then fold in crabmeat.

- [ ] Pour in oil to come 1½" up sides of a large pot or deep fryer. Fit pot with thermometer and heat oil over medium-high to 350°. Place a wire rack inside a rimmed baking sheet and line rack with paper towels. Working in 4 or 5 batches, scoop out heaping tablespoons of batter, carefully place in oil (8–10 per batch) and fry, turning often, until beignets are golden brown and cooked through, about 5 minutes. Transfer beignets to prepared rack; season with salt.

- [ ] Serve beignets warm with yaji aioli for dipping.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/corn-and-crab-beignets-with-yaji-aioli