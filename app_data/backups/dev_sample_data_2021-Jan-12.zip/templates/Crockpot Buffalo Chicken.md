

![Recipe Image](../images/crockpot-buffalo-chicken.jpg)

# Crockpot Buffalo Chicken
{'This is a party favorite, perfect for a Super Bowl or a game night. It takes a long time, but like most slow cooker recipes, is easy as hell. Bonus': 'guests love it.'}

## Ingredients

- [ ] 6-8 chicken breasts

- [ ] 1 packet ranch mix

- [ ] 1 bottle Frank's Red Hot

- [ ] 1 stick of butter


## Instructions

- [ ] Add all the above into a crockpot, cook on low for 6-8 hours

- [ ] Shred chicken when soft

- [ ] Serve with pickles and Hawaiian rolls




---

Tags: ['mains', ' grill', ' party']
Categories: []
Original URL: 