

![Recipe Image](../images/buttery-kimchi-chicken.jpg)

# Buttery Kimchi Chicken
This spicy and sweet, slightly nutty, and creamy stew from developer Sunny Lee is worth the tending (and time) it requires over the stove.

## Ingredients

- [ ] 1 cup plain whole-milk Greek yogurt

- [ ] 4 garlic cloves, finely chopped

- [ ] 1 2" piece ginger, peeled, finely chopped

- [ ] 3 Tbsp. gochugaru (coarse Korean red pepper powder)

- [ ] 1 Tbsp. fish sauce

- [ ] 1 Tbsp. Diamond Crystal or 1¾ tsp. Morton kosher salt

- [ ] 1 tsp. freshly ground black pepper

- [ ] 2 lb. skinless, boneless chicken thighs

- [ ] ½ cup dried soybeans

- [ ] 2 Tbsp. vegetable oil

- [ ] 1 onion, sliced ½" thick

- [ ] 2 cups drained Napa cabbage kimchi, cut into 2" pieces

- [ ] 2 Tbsp. plus 1½ tsp. tomato paste

- [ ] 1½ cups low-sodium chicken broth

- [ ] 4 Tbsp. unsalted butter

- [ ] Cooked white rice (for serving)

- [ ] 3 scallions, thinly sliced

- [ ] 1 red chile (such as Fresno), thinly sliced

- [ ] Pickles (for serving; optional)


## Instructions

- [ ] Mix yogurt, garlic, ginger, gochugaru, fish sauce, salt, and pepper in a medium bowl. Cut chicken thighs crosswise into thirds and add to bowl. Massage yogurt mixture into chicken until well coated. Cover and chill at least 1 hour and up to 3 hours.

- [ ] Meanwhile, place soybeans in a medium saucepan and pour in 2 cups cold water; bring to a boil. Immediately drain soybeans and rinse under cold running water. Return to pot, pour in 1 cup cold water, and bring to a boil again. Immediately remove from heat and let cool slightly. Transfer soybeans and water to a blender and blend until a thick purée forms. (It’s okay if the soybeans are a bit chunky still; they’ll soften in the braise.) Set aside.

- [ ] Heat oil in a large Dutch oven over medium-high. Working in 2 batches, remove chicken from marinade, letting any marinade that wants to cling stay on, and cook, stirring occasionally, until browned all over, 5–7 minutes per batch. Using a slotted spoon, transfer chicken to a plate as you go, leaving all the crunchy bits and oil in pot. Set any remaining marinade aside.

- [ ] Reduce heat to medium-high. Combine onion, kimchi, tomato paste, and reserved marinade in same pot and cook, stirring and scraping up browned bits constantly to prevent burning, until onion is softened and tomato paste darkens slightly and begins to stick to bottom of pot, about 10 minutes. Return chicken, along with any juices collected on plate, to pot and stir in broth, butter, and reserved soybean purée. Bring to a simmer and cook until chicken is just cooked through, 10–15 minutes.

- [ ] Divide rice among bowls and ladle chicken mixture over. Top with scallions and chile. Serve with pickles alongside if desired.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/buttery-kimchi-chicken