

![Recipe Image](../images/marinated-tofu-with-brussels-sprouts-and-farro.jpg)

# Marinated Tofu With Brussels Sprouts and Farro
The soul of this recipe comes from the ginger and tamari marinade that gives a sweet and savory winter coat to the crispy tofu. 

## Ingredients

- [ ] 1 cup semi-pearled farro or cracked freekeh, rinsed

- [ ] Kosher salt

- [ ] 1 14-oz. block extra-firm tofu

- [ ] 1 1½" piece ginger, peeled, finely  grated

- [ ] 2 Tbsp. tamari or low-sodium soy  sauce

- [ ] 1 Tbsp. fish sauce

- [ ] 1 tsp. ground cumin

- [ ] 6 scallions, coarsely chopped

- [ ] 12 oz. brussels sprouts, trimmed,  halved through stem end

- [ ] 4 Tbsp. vegetable oil, divided½ lemon

- [ ] ⅓ cup coarsely chopped parsley or cilantro


## Instructions

- [ ] Preheat oven to 425°. Toast farro in a large wide pot over medium heat,  stirring often, until golden brown, about 4 minutes. Remove from heat and pour in cold water to cover grains by 1"; season generously with salt. Set pot over medium-high heat and bring water to a boil. Reduce heat and simmer, skimming foam from surface, until grains are tender but still have some bite, 25–30 minutes. Drain farro and return to pot off heat; cover to keep warm.

- [ ] While farro is cooking, cut tofu lengthwise to create 2 wide, flat slabs.  Pat dry with paper towels to remove as much moisture from surface as possible. Arrange in a single layer in a large shallow bowl.

- [ ] Whisk ginger, tamari, fish sauce, and cumin in a small bowl to combine. Pour half of marinade over tofu and gently turn to coat evenly.

- [ ] Toss scallions and brussels sprouts with 2 Tbsp. oil and remaining marinade on a large rimmed baking sheet to coat well; season with salt. Spread out vegetables to ensure everything cooks evenly and roast, tossing halfway through, until deeply browned in spots, 20–25 minutes.

- [ ] Finely grate zest from lemon over vegetables, then squeeze juice over. Add parsley and toss well to combine.

- [ ] Heat remaining 2 Tbsp. oil in a large nonstick skillet over medium-high. Working in batches if needed, cook tofu, undisturbed, until dark brown and very crisp, about 2 minutes. Carefully turn over and cook on other side until dark brown and very crisp, about 2 minutes. Transfer tofu to a cutting board and slice as desired.

- [ ] Divide farro and tofu evenly among bowls. Scatter brussels sprouts mixture on top.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/marinated-tofu-with-brussels-sprouts-and-farro