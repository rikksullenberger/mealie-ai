

![Recipe Image](../images/detroit-style-pepperoni-pizza.jpg)

# Detroit-Style Pepperoni Pizza
So you want to make pizza, but it’s your first time. This Detroit-style pizza from Bryan Ford, which uses a half-batch of his Master Dough, is perfect for beginners because you don’t have to shape the dough or wrangle a hot pizza stone. If you don’t have a Detroit pizza pan (its deep sides and black anodized aluminum help achieve a crust that’s fluffy on the inside but crisp all around), that’s okay: Use a 13x9" baking pan or two 8x8" baking pans.

## Ingredients

- [ ] Extra-virgin olive oil (for pan)

- [ ] Bread flour (for surface)

- [ ] ½ batch (360 g) Master Bread Dough

- [ ] 8 oz. low-moisture mozzarella or brick cheese

- [ ] ¾ cup store-bought marinara sauce

- [ ] 4 oz. pepperoni, sliced

- [ ] ½ tsp. dried oregano

- [ ] ½ cup (lightly packed) basil leaves


## Instructions

- [ ] To make this recipe, start by preparing a half-batch of the Master Bread Dough.

- [ ] Lightly brush Detroit-style pizza pan, 13x9" baking pan, or two 8x8" pans with extra-virgin olive oil. Lightly flour work surface with bread flour and turn ½ batch (360 g) Master Bread Dough out onto surface. If using a Detroit-style pizza pan or a 13x9" pan, pull edges of dough into the center, then turn over and hold opposite sides of the dough with your hands so the sides of your pinkies are touching the surface and rotate dough, gently working it into a round as you go. If using two 8x8" pans, divide dough in half and form using the same method as above. Gently transfer dough to prepared pan. Rub dough with oil and cover with a kitchen towel. Let rise in a warm, draft-free spot until dough expands a bit and is smooth and more pliable, about 1 hour.

- [ ] Meanwhile, cut 8 oz. low-moisture mozzarella or brick cheese into small cubes. You should have 2 heaping cups.

- [ ] Place a rack in middle of oven; preheat to 450°. Dimple dough with your fingers, gently pushing out to edges of pan. Scatter cheese evenly over dough all the way to the edges. Spoon ¾ cup store-bought marinara sauce over pizza in three even rows. Next, distribute 4 oz. pepperoni, sliced, evenly over sauce. Sprinkle with ½ tsp. dried oregano.

- [ ] Bake pizza until crust is deep golden brown, 35–40 minutes. (You can also check doneness with an instant-read thermometer. It should register 190° when inserted into a thick part of the crust.) Remove from oven and top with ½ cup (lightly packed) basil leaves. Let cool in pan 5 minutes before slicing.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/detroit-style-pepperoni-pizza