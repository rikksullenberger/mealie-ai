

![Recipe Image](../images/shrimp-and-cabbage-curry.jpg)

# Shrimp and Cabbage Curry
Make this shrimp and cabbage curry vegetarian by skipping the shrimp and using cubed pumpkin or squash instead.

## Ingredients

- [ ] 1 red bell pepper, ribs and seeds  removed, coarsely chopped

- [ ] 2 red Thai chiles or 1 small red Fresno chile, seeds removed if  desired, coarsely chopped

- [ ] 1 lemongrass stalk, bottom third only, tough outer layers removed, finely chopped

- [ ] 4 garlic cloves, smashed

- [ ] 1 4" piece ginger, peeled, finely  grated

- [ ] 2 Tbsp. smoked paprika

- [ ] 2 tsp. ground coriander

- [ ] 1 tsp. ground cumin

- [ ] 1 tsp. ground turmeric

- [ ] Kosher salt

- [ ] 3 Tbsp. (or more) virgin coconut oil

- [ ] ½ medium head of green cabbage, cut into 4 wedges through  root end

- [ ] 1 13.5-oz. can unsweetened  coconut milk

- [ ] Kosher salt

- [ ] 1 lb. large shrimp, shelled, deveined

- [ ] 4 scallions, chopped

- [ ] 2 tsp. finely grated lime zest

- [ ] 2 Tbsp. fresh lime juice

- [ ] Small handful of torn tender herbs (such as cilantro, basil, and/or  mint)

- [ ] Lime wedges (for serving)


## Instructions

- [ ] Blend red bell pepper, chiles, lemongrass, garlic, ginger, paprika, coriander, cumin, turmeric, and a couple of big pinches of salt in a blender until a smooth paste forms.

- [ ] Heat oil in a large pot over medium-high. Cook cabbage until deeply browned on both cut sides, about  2 minutes per side. Transfer to a plate.

- [ ] If pot looks dry, add another 1 Tbsp. oil. Add curry paste to pot (still over medium-high heat) and cook, stirring often, until paste is slightly darkened in color and beginning to stick to bottom of pot, about 5 minutes. Pour coconut milk and 2 cups water into pot and reduce heat to medium; season with salt. Cook, scraping up any curry paste stuck to pot until flavors come together and curry is slightly thickened, 10–12 minutes.

- [ ] While the curry is cooking, coarsely chop cabbage.

- [ ] Season shrimp with salt and add to curry. Cook, stirring, until shrimp are just cooked through, about 3 minutes. Remove pot from heat; stir in cabbage, scallions, and lime zest and juice.

- [ ] Divide curry among bowls and top with herbs. Serve with lime wedges.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/shrimp-and-cabbage-curry