

![Recipe Image](../images/pace-pork.jpg)

# Pace Pork
This recipe comes from Cody, a childhood neighbor and friend that my brother and I group chat message about food literally every day. Hey Cody!
Consider this a starting point. This is totally one of those "starter meats" that you coud add to almost any dish.

## Ingredients

- [ ] pork shoulder (or loin)

- [ ] 1 jar of Pace Picante


## Instructions

- [ ] Combine the pork and Pace Picante in the crockpot

- [ ] Cook on slow for 8hrs or so (until it shreds)

- [ ] Eat on buns, on tortillas, with chips or nachos, etc




---

Tags: ['mains', ' crock pot']
Categories: []
Original URL: 