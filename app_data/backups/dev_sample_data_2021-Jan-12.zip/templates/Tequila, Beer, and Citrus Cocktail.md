

![Recipe Image](../images/tequila-beer-and-citrus-cocktail.jpg)

# Tequila, Beer, and Citrus Cocktail
The holiday cocktail that takes you straight to the beach (and isn’t that where you want to be anyway?). 

## Ingredients

- [ ] ¾ oz. fresh grapefruit juice

- [ ] ¾ oz. fresh lime juice

- [ ] ½ oz. agave nectar

- [ ] 2 Tbsp. red pepper jelly

- [ ] 1½ oz. tequila blanco

- [ ] 1 12-oz. chilled Mexican beer

- [ ] Lime wedge (for serving)


## Instructions

- [ ] Combine grapefruit juice, lime juice, agave, and jelly in a cocktail shaker filled with ice and shake until incorporated, 15–20 seconds. Add tequila and shake 10 seconds longer. Fill a tall glass to the top with ice. Pour in beer just to fill the glass halfway. Double-strain grapefruit mixture into glass; garnish with lime wedge.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/tequila-beer-and-citrus-cocktail