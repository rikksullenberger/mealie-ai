

![Recipe Image](../images/green-chile-stew.jpg)

# Green Chile Stew
This is a simple one, consisting of a pre-made soup mix and whatever you've got around the kitchen (or campsite). Feel free to sub/swap/switch anything in the ingredient list— anything's fair game!

## Ingredients

- [ ] 1 jar of [green chile stew mix](http://amzn.to/1KYXSjo)

- [ ] 1lb ground chicken

- [ ] 1 red onion

- [ ] 1 green onion

- [ ] 1 can corn


## Instructions

- [ ] Start onions in pan, cook down

- [ ] Add chicken, corn

- [ ] Add stew mix

- [ ] Serve with croutons




---

Tags: ['sides', ' soups']
Categories: []
Original URL: 