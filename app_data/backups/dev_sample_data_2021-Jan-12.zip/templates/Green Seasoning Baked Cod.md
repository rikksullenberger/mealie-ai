

![Recipe Image](../images/green-seasoning-baked-cod.jpg)

# Green Seasoning Baked Cod
Herbaceous, aromatic, fresh, and—maybe most importantly—simple, this Trini-inspired recipe from Brigid Washington is just the cure for those January blues.

## Ingredients

- [ ] ¼ Vidalia or other sweet onion

- [ ] 4 6-oz. skinless, boneless cod fillets

- [ ] 1½ tsp. Diamond Crystal or ¾ tsp. Morton kosher salt, divided

- [ ] Freshly ground black pepper

- [ ] ¼ cup plus 2 tsp. extra-virgin olive oil

- [ ] 1 lime

- [ ] 4 garlic cloves

- [ ] 1 2" piece ginger

- [ ] 4–5 thyme sprigs

- [ ] 1 small bunch cilantro

- [ ] 2–4 scallions

- [ ] 1 red bell pepper

- [ ] 1 habanero chile

- [ ] Cooked brown rice or ramen noodles (for serving)


## Instructions

- [ ] Preheat oven to 300°. Thinly slice ¼ Vidalia or other sweet onion with a chef’s knife and place in a medium baking dish. Place four 6-oz. skinless, boneless cod fillets on top of onion slices. Generously sprinkle fillets on both sides with 1 tsp. Diamond Crystal or ½ tsp. Morton kosher salt and season with freshly ground black pepper. Pour ¼ cup extra-virgin olive oil over, then finely grate zest from 1 lime on top; set lime aside. Turn fillets to coat. Let cod sit while you prepare remaining ingredients.

- [ ] Smash, peel, and coarsely chop 4 garlic cloves. Peel one 2" piece ginger with a spoon, then thinly slice; place in a small bowl. Cut slices into matchsticks; cut matchsticks into small cubes. Place garlic and ginger in a small bowl.

- [ ] Pick leaves off 4–5 thyme sprigs and chop; discard stems. You should have about 1 Tbsp. chopped thyme. Coarsely chop leaves and tender stems from 1 small bunch cilantro until you have ½ cup (reserve remaining cilantro for another use); add herbs to bowl with garlic and ginger.

- [ ] Trim and coarsely chop 2–4 scallions to yield about ⅓ cup and place in same bowl.

- [ ] Slice 1 red bell pepper in half lengthwise and remove ribs and seeds; discard. Finely chop flesh and add to bowl. Slice 1 habanero chile in half lengthwise and remove ribs and seeds; discard. Finely chop half of chile; reserve remaining chile for another use. Add bell pepper and chile to bowl and toss all ingredients with your hands to combine.

- [ ] Spoon mixture evenly over cod to completely cover. Slice reserved lime in half and squeeze juice over; sprinkle with remaining ½ tsp. Diamond Crystal or ¼ tsp. Morton kosher salt and drizzle with remaining 2 tsp. extra-virgin olive oil. Bake until fish is opaque and cooked through and red pepper and chile are softened, 25–35 minutes. Serve cod with cooked brown rice or ramen noodles.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/green-seasoning-baked-cod