

![Recipe Image](../images/banana-bread.jpg)

# Banana Bread
From Angie's mom

## Ingredients

- [ ] 4 bananas

- [ ] 1/2 cup butter

- [ ] 1/2 cup sugar

- [ ] 2 eggs

- [ ] 2 cups flour

- [ ] 1/2 tsp baking soda

- [ ] 1 tsp baking powder

- [ ] pinch salt

- [ ] 1/4 cup nuts (we like pecans)


## Instructions

- [ ] Beat the eggs, then cream with the butter and sugar

- [ ] Mix in bananas, then flour, baking soda/powder, salt, and nuts

- [ ] Add to greased and floured pan

- [ ] Bake until brown/cracked, toothpick comes out clean




---

Tags: ['breakfast', ' baking']
Categories: []
Original URL: 