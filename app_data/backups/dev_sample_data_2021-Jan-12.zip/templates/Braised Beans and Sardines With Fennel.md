

![Recipe Image](../images/braised-beans-and-sardines-with-fennel.jpg)

# Braised Beans and Sardines With Fennel
Tinned sardines add briney flavor (and protein!)—leave them whole or break them up and fold them into the soup.

## Ingredients

- [ ] 1 fennel bulb with fronds, stalks and fronds removed

- [ ] 1 lemon, halved

- [ ] ¼ cup extra-virgin olive oil

- [ ] 2 medium shallots, thinly sliced

- [ ] 6 garlic cloves, thinly sliced

- [ ] Small handful of mixed hardy herb sprigs (such as bay leaves, thyme, and/or rosemary)

- [ ] ½ tsp. crushed red pepper flakes

- [ ] ¼ cup dry white wine

- [ ] 6 cups low-sodium chicken broth

- [ ] 2 15-oz. cans cannellini (white kidney) or cranberry beans, rinsed1 4.4-oz. tin oil-packed sardines, drained

- [ ] 1 (loosely packed) cup very coarsely chopped parsley

- [ ] Kosher salt

- [ ] Toasted seeded bread (for serving)


## Instructions

- [ ] Slice fennel bulb in half lengthwise and cut each half lengthwise into 3 wedges. Thinly slice 1 lemon half into rounds and wriggle out and discard any seeds; leave remaining half intact and set aside.

- [ ] Heat oil in a medium pot over medium-high. Add fennel, shallots, garlic, hardy herbs, lemon rounds, and red pepper flakes and cook, stirring occasionally, until fennel and lemon are softened slightly and golden brown in spots, 5–7 minutes.

- [ ] Using tongs, transfer lemon rounds to a small bowl; set aside. Add wine to pot and cook until reduced by half, about  2 minutes. Pour in broth and bring to a boil. Reduce heat to medium-low and simmer, stirring occasionally, until fennel is tender, about 5 minutes. Add beans and simmer until beans soak up some of the broth and are warmed through, 8–10 minutes.

- [ ] Meanwhile, working one at a time, slice open each sardine with the tip of a paring knife and remove any visible bones; discard. Separate fillets from one another and place in a small bowl. Squeeze juice from remaining reserved lemon half over fillets.

- [ ] Fish out and discard any hardy herbs and stems you can from braise. Stir in parsley; taste and season broth with more salt if needed.

- [ ] Divide braise among bowls; top with reserved lemon slices and sardines. Serve with bread alongside.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/braised-beans-and-sardines-with-fennel