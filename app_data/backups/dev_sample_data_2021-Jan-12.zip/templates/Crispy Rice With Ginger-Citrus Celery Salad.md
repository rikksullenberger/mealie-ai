

![Recipe Image](../images/crispy-rice-with-ginger-citrus-celery-salad.jpg)

# Crispy Rice With Ginger-Citrus Celery Salad
To get the best texture, evenly distribute the rice in your pan and gently press down to flatten it. Don’t touch until you hear it crackle! 

## Ingredients

- [ ] 1 2" piece ginger, peeled, finely grated

- [ ] 1 small garlic clove, finely grated

- [ ] Juice of 1 orange

- [ ] 2 tbsp. vegetable oil

- [ ] 1Tbsp. coconut aminos or low-sodium soy sauce

- [ ] 1 Tbsp. fresh lemon juice

- [ ] ¼ tsp. toasted sesame oil

- [ ] Kosher salt

- [ ] 1 medium head of broccoli

- [ ] 6 Tbsp. (or more) vegetable oil, divided

- [ ] Kosher salt

- [ ] 2 cups chilled cooked brown rice

- [ ] 4 large eggs

- [ ] 3 celery stalks, thinly sliced on a steep diagonal

- [ ] ½ cup cilantro leaves with tender stems

- [ ] ½ cup mint leaves

- [ ] Crushed red pepper flakes (for serving)


## Instructions

- [ ] Whisk ginger, garlic, orange juice, vegetable oil, coconut aminos, lemon juice, and sesame oil in a small bowl; season with salt and set aside.

- [ ] Trim about ½" from woody end of broccoli stem. Peel tough outer layer from stem. Cut florets from stems and thinly slice stems about ½" thick. Break florets apart with your hands into 1"–1½" pieces.

- [ ] Heat 2 Tbsp. oil in a large nonstick skillet over medium. Working in 2 batches if needed, arrange broccoli in a single layer and cook, tossing occasionally, until broccoli is bright green and lightly charred around the edges, about 3 minutes. Transfer to a large plate.

- [ ] Pour 2 Tbsp. oil into same pan and heat over medium-high. Once you see the first wisp of smoke, add rice and season lightly with salt. Using a spatula or spoon, press rice evenly into pan like a pancake. Rice will begin to crackle, but don’t fuss with it. When the crackling has died down almost completely, about 3 minutes, break rice into large pieces and turn over.

- [ ] Add broccoli back to pan and give everything a toss to combine. Cook, tossing occasionally and adding another 1 Tbsp. oil if pan looks dry, until broccoli is tender and rice is warmed through and very crisp, about 5 minutes. Transfer mixture to a platter or divide among plates and set aside.

- [ ] Wipe out skillet; heat remaining 2 Tbsp. oil over medium-high. Crack eggs into skillet; season with salt. Oil should bubble around eggs right away. Cook, rotating skillet occasionally, until whites are golden brown and crisp at the edges and set around the yolk (which should be runny), about 2 minutes.

- [ ] Toss celery, cilantro, and mint with 3 Tbsp. reserved dressing and a pinch of salt in a medium bowl to combine.

- [ ] Scatter celery salad over fried rice; top with fried eggs and sprinkle with red pepper flakes. Serve extra dressing alongside.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/crispy-rice-with-ginger-citrus-celery-salad